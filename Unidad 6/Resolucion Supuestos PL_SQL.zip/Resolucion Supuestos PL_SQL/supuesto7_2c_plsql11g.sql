variable i number;
/
begin
  :i := factorial(-1);
end;
/
print i;
/
