CREATE OR REPLACE PROCEDURE BUSCA_ENFERMOS(codigo IN NUMBER) IS
		Cuenta		NUMBER;
		V_nombre		enfermo.nombre%TYPE;
		V_apellidos	enfermo.apellidos%TYPE;
BEGIN
     SELECT NOMBRE, APELLIDOS INTO v_nombre, v_apellidos
     FROM ENFERMO, HOSPITAL_ENFERMO
     WHERE HOSP_CODIGO = CODIGO
     AND NUMSEGSOCIAL = ENF_NUMSEGSOCIAL;
     DBMS_OUTPUT.PUT_LINE('El �nico enfermo del hospital '||TO_CHAR(CODIGO)||' es '||v_nombre||','||v_apellidos);
EXCEPTION
		WHEN NO_DATA_FOUND THEN
		         DBMS_OUTPUT.PUT_LINE('No hay enfermos en el hospital con c�digo '||TO_CHAR(codigo));
 	  WHEN TOO_MANY_ROWS THEN
		         SELECT COUNT(DISTINCT ENF_NUMSEGSOCIAL) INTO cuenta FROM HOSPITAL_ENFERMO
 		         WHERE HOSP_CODIGO = codigo;
 		         DBMS_OUTPUT.PUT_LINE('El hospital con c�digo '||TO_CHAR(codigo)||' tiene '||TO_CHAR(cuenta)||' enfermos.');
END;

