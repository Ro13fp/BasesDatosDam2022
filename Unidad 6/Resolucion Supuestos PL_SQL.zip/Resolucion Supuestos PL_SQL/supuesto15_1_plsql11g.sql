CREATE OR REPLACE PROCEDURE EQUIPARAR_SALARIOS IS
		V_salariomax	plantilla.salario%TYPE;
		CURSOR mi_cursor IS
			SELECT * FROM plantilla
			WHERE EXISTS (SELECT NULL FROM doctor
						        WHERE doctor.nif = plantilla.nif
						        AND doctor.especialidad = plantilla.funcion)
		  FOR UPDATE OF salario;
BEGIN
		FOR v_empleado_sanitario IN mi_cursor LOOP
			  SELECT max(salario) INTO v_salariomax
			  FROM plantilla;

			  UPDATE plantilla
			  SET salario = v_salariomax
			  WHERE CURRENT OF mi_cursor;
		END LOOP;
		COMMIT;
END equiparar_salarios;
