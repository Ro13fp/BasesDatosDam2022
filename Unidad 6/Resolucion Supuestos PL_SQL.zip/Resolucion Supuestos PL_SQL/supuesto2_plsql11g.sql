SET SERVEROUTPUT ON
DECLARE
  V_NOMBRE    ENFERMO.NOMBRE%TYPE := '&nombre_de_enfermo';
  V_APELLIDOS ENFERMO.APELLIDOS%TYPE := '&apellidos_del_mismo';
  V_DIRECCION ENFERMO.DIRECCION%TYPE := '&direccion_donde_reside';
  CUENTA      NUMBER(3);
BEGIN
   SELECT COUNT(*) INTO cuenta FROM enfermo;
   DBMS_OUTPUT.PUT_LINE(CHR(10)||CHR(10)||'N� de filas en tabla enfermo antes de insertar = '||cuenta);
   INSERT INTO ENFERMO (NUMSEGSOCIAL,NOMBRE,APELLIDOS,DIRECCION,SEXO)
   VALUES (280862486,v_nombre,v_apellidos,v_direccion,'M');
   FOR I IN 1..10 LOOP
      INSERT INTO HOSPITAL_ENFERMO (HOSP_CODIGO, INSCRIPCION, ENF_NUMSEGSOCIAL, FINSCRIPCION)
      VALUES (6,seq_inscripcion.nextval,280862486,TO_DATE('01012000','DDMMYYYY') + seq_inscripcion.nextval);
   END LOOP;
   ROLLBACK;
   SELECT COUNT(*) INTO cuenta FROM enfermo;
   DBMS_OUTPUT.PUT_LINE('N� de filas en tabla enfermo despu�s de insertar y rechazar filas = '||cuenta);
END;
/
