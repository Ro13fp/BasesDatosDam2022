/* Creamos una tabla estudiantes */
CREATE TABLE estudiantes
(ID  NUMBER PRIMARY KEY,
 NOMBRE VARCHAR2(25),
 APELLIDOS VARCHAR2(30));
/

/* Creamos una secuencia */
CREATE SEQUENCE contador
START WITH 1
INCREMENT BY 1
NOCACHE;
/

CREATE OR REPLACE TRIGGER GeneraID
BEFORE INSERT OR UPDATE ON estudiantes
FOR EACH ROW
BEGIN
   SELECT CONTADOR.NEXTVAL INTO :NEW.ID FROM DUAL;
END;
/

/* Hacemos una primera inserci�n en la tabla estudiantes */
INSERT INTO estudiantes VALUES(10,'Juan','Gabriel Sanchez');

/* Vemos que se ha insertado en realidad en tabla ESTUDIANTES */
SELECT * FROM estudiantes;

/* Realizamos otro insert en tabla ESTUDIANTES */
INSERT INTO estudiantes (NOMBRE, APELLIDOS) VALUES ('Pepe','Domingo Castro');

/* Vemos que se ha insertado */
SELECT * FROM estudiantes;

/* Como se puede ver por las 2 inserciones el trigger lo que hace
   es dar un valor para el campo ID (el valor del siguiente n�mero de la secuencia)
   independientemente de que se inserte o no un valor para dicho campo */
/* Fin de la ejecuci�n del trigger */
