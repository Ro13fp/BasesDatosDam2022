SET SERVEROUTPUT ON
DECLARE
  TYPE R_Ocupacion_Departamentos IS RECORD
    (Nombre_dpto    DEPARTAMENTO.NOMBRE%TYPE,
    Ocupacion       NUMBER(5),
    Tipo_Ocupacion  VARCHAR2(20));
    
  TYPE T_Ocupacion_Departamento IS TABLE OF R_Ocupacion_Departamentos
    INDEX BY BINARY_INTEGER;
  
  V_Ocupacion T_Ocupacion_Departamento;
BEGIN
   SELECT D.NOMBRE, COUNT(E.EMP_NIF)
   INTO V_Ocupacion(1).Nombre_dpto, V_Ocupacion(1).Ocupacion
   FROM DEPARTAMENTO D, DEPARTAMENTO_EMPLEADO E
   WHERE UPPER(D.NOMBRE) = UPPER('&Indique_departamento')
   AND E.DEPT_CODIGO = D.CODIGO
   GROUP BY D.NOMBRE;
   
   IF V_Ocupacion(1).Ocupacion < 10 THEN
      V_Ocupacion(1).Tipo_Ocupacion := 'BAJA';
   ELSIF V_Ocupacion(1).Ocupacion BETWEEN 10 AND 19 THEN
      V_Ocupacion(1).Tipo_Ocupacion := 'MEDIA';
   ELSE 
      V_Ocupacion(1).Tipo_Ocupacion := 'ALTA';
   END IF;
   
   DBMS_OUTPUT.PUT_LINE(CHR(10)||CHR(10)||'Datos de ocupaci�n del departamento '||V_Ocupacion(1).Nombre_dpto);
   DBMS_OUTPUT.PUT_LINE('--------------------------------------------------'||CHR(10)||CHR(10));
   DBMS_OUTPUT.PUT_LINE('Ocupaci�n actual (Tipo/n�empleados): '||V_Ocupacion(1).Tipo_Ocupacion||'/'||V_Ocupacion(1).Ocupacion);
  
END;
/
