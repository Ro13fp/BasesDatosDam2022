/* Creamos una tabla denomina ESTUDIANTE */
CREATE TABLE ESTUDIANTE
(NOMBRE VARCHAR2(10));
/

/* Creamos una tabla denomina SUCESOS */
CREATE TABLE SUCESOS
(NOMBRE VARCHAR2(50),
 EN_TABLA VARCHAR2(10),
 DIA DATE);
/

/* Creamos un trigger asociado a la tabla estudiante
   que se dispara cuando se produce una operaci�n de INSERT
   sobre dicha tabla y que tiene como misi�n insertar una fila */
CREATE OR REPLACE TRIGGER GRABA_SUCESO
BEFORE INSERT ON ESTUDIANTE
BEGIN
  INSERT INTO SUCESOS VALUES ('TRIGGER','ESTUDIANTE',SYSDATE);
END GRABA_SUCESO;
/

/* Seleccionamos todas las filas de la tabla ESTUDIANTE */
SELECT * FROM ESTUDIANTE;

/* Seleccionamos todas las filas de la tabla SUCESOS */
SELECT * FROM SUCESOS;

/* Realizamos un select sobre la tabla del sistema USER_OBJECTS
   que nos devuelve el nombre, tipo y estado del trigger cuyo nombre
   empieza por GRA para ver en que estado se encuentran */
SELECT OBJECT_NAME, OBJECT_TYPE, STATUS FROM USER_OBJECTS
WHERE OBJECT_NAME LIKE 'GRA%';

/* Insertamos una fila en la tabla ESTUDIANTE lo cual provoca que
   se dispare nuestro trigger GRABA_SUCESO */
INSERT INTO ESTUDIANTE VALUES ('PEPITO');

/* Seleccionamos todas las filas de la tabla ESTUDIANTE para comprobar
   que se ha ejecutado el INSERT anterior. */
SELECT * FROM ESTUDIANTE;

/* Seleccionamos todas las filas de la tabla SUCESOS para comprobar
   que se ha disparado nuestro trigger GRABA_SUCESO */
SELECT * FROM SUCESOS;

/* Nos arrepentimos y deshacemos el INSERT sobre la tabla ESTUDIANTES
   �que ocurre entonces con la tabla SUCESOS y su informaci�n generada
   por el trigger GRABA_SUCESO? */
ROLLBACK;

/* Seleccionamos todas la filas de la tabla ESTUDIANTE y vemos que tras
   el ROLLBACK volvemos al estado inicial que era una tabla sin filas */
SELECT * FROM ESTUDIANTE;

/* El ROLLBACK deshace cualquier operaci�n de actualizaci�n realizada o sea
   que tambi�n deja la tabla SUCESOS como estaba al principio, sin filas
   para ello ejecutamos la select que devuelve todos los datos y vemos que  
   est� vac�a */
SELECT * FROM SUCESOS;

/* Volvemos a ejecutar la operaci�n de inserci�n sobre tabla ESTUDIANTE */
INSERT INTO ESTUDIANTE VALUES ('PEPITO');

/* Confirmamos la inserci�n y la hacemos definitiva */
COMMIT;

/* Consultamos las filas de la tabla ESTUDIANTE */
SELECT * FROM ESTUDIANTE;

/* Consultamos las filas de la tabla SUCESOS y vemos que se ha ejecutado
   el trigger */
SELECT * FROM SUCESOS;

/* Borramos la tabla ESTUDIANTE */
DROP TABLE ESTUDIANTE;

/* Consultamos la tabla SUCESOS para ver si su estado ha variado al borrar
   la tabla ESTUDIANTE y vemos que no ha variado */
SELECT * FROM SUCESOS;

/* Consultamos la tabla del sistema USER_OBJECTS para ver que ha ocurrido
   con el trigger al borrar la tabla sobre la que estaba asociado el mismo. El
   resultado es que se ha borrado tambi�n porque un trigger depende de una tabla
   y si la misma se borra, se eliminan autom�ticamente todos los elementos asociados
   a ella: Indices, Vistas y Triggers */
SELECT * FROM USER_OBJECTS WHERE OBJECT_NAME LIKE 'GR%';

/* Borramos la tabla sucesos */
drop table sucesos;

/* Fin del ejemplo de utilizaci�n de TRIGGERS */
