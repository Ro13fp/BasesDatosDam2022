CREATE OR REPLACE PROCEDURE supuesto6 (letra IN CHAR, el_turno IN CHAR, filas OUT NUMBER) IS
texto_turno  VARCHAR2(20);
BEGIN
  SELECT DECODE(el_turno, 'T','Tarde','N','Noche','M','Ma�ana','Desconodido') INTO texto_turno FROM DUAL;
/* Atenci�n, aunque un cursor impl�cito SQL no permite solucionar el problema de que un SELECT no devuelva filas
   o devuelva m�s de una fila, si que cuenta el n�mero de filas que selecciona cuando no da error, es decir
   cuando un SELECT devuelve 1 fila => SQL%ROWCOUNT = 1 */
      
  UPDATE plantilla a
  SET a.salario = a.salario / 12
  WHERE
    Upper(a.nombre) like upper(letra)||'%'
  AND a.salario >= (SELECT MAX(b.salario) FROM plantilla b);
  
  IF SQL%NOTFOUND THEN
      UPDATE plantilla a
      SET a.salario = a.salario / 12
      WHERE
          Upper(a.turno) = upper(el_turno)
      AND a.salario >= (SELECT MAX(b.salario) FROM plantilla b);
      
       IF SQL%NOTFOUND THEN
        filas := 0;
        DBMS_OUTPUT.PUT_LINE('No se ha podido actualizar ningun empleado de la plantilla sanitaria cuya letra comience por '
        ||letra);
        DBMS_OUTPUT.PUT_LINE('No se ha podido actualizar ningun empleado de la plantilla sanitaria cuya turno sea '||texto_turno);
      ELSE
        filas := SQL%ROWCOUNT;
        DBMS_OUTPUT.PUT_LINE('Se han actualizado '||SQL%ROWCOUNT||' filas, correspondientes a la plantilla sanitaria cuyo turno es '||texto_turno);
      END IF;
  ELSE
      filas := SQL%ROWCOUNT;
      DBMS_OUTPUT.PUT_LINE('Se han actualizado '||SQL%ROWCOUNT||' filas, correspondientes a la plantilla sanitaria cuya letra comienza por la letra '||letra);
  END IF;
  ROLLBACK;
END supuesto6;
