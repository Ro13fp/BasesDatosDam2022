SET SERVEROUTPUT ON
DECLARE
  contador            NUMBER := 0;
  SUBTYPE nombre IS   empleado.nombre%TYPE;
  nombre_empleado     nombre;
  nombre_dpto         nombre;
  v_codigo            departamento.codigo%TYPE;
  TYPE t_nombre IS TABLE OF nombre INDEX BY BINARY_INTEGER;
  v_nombre            t_nombre;
  CURSOR c_departamento (valor departamento.codigo%TYPE) IS
    select nombre from departamento_empleado, empleado
    where dept_codigo = v_codigo
    and nif = emp_nif;
        
BEGIN
  FOR I IN 1..6 LOOP
         IF I != 4 THEN
               INSERT INTO DEPARTAMENTO_EMPLEADO VALUES (I,'10000000A');
         END IF;
  END LOOP;
  COMMIT;

  v_codigo := &Codigo_departamento;
  OPEN c_departamento(v_codigo);
  LOOP
      FETCH c_departamento INTO nombre_empleado;
      EXIT WHEN c_departamento%NOTFOUND;
      contador := contador + 1;
      v_nombre(contador) := nombre_empleado;
  END LOOP;
  IF c_departamento%ROWCOUNT < 1 THEN
    DBMS_OUTPUT.PUT_LINE(CHR(10)||'No se recuper� ningun empleado en el departamento con c�digo '||v_codigo);
  ELSE
    SELECT COUNT(*) INTO contador FROM DEPARTAMENTO_EMPLEADO
    WHERE DEPT_CODIGO = v_codigo;
    
    SELECT NOMBRE INTO nombre_dpto FROM DEPARTAMENTO
    WHERE CODIGO = v_codigo;
    DBMS_OUTPUT.PUT_LINE(CHR(10)||'Se han encontrado '||contador||' empleados pertenecientes al departamento  '||nombre_dpto);
    
    DBMS_OUTPUT.PUT_LINE(CHR(10)||'Relaci�n de empleados del departamento '||nombre_dpto||'.');
    DBMS_OUTPUT.PUT_LINE(CHR(10)||'------------------------------------------------'||CHR(10));
  
    FOR indice IN v_nombre.FIRST..v_nombre.LAST LOOP
        IF v_nombre.EXISTS(indice) THEN
            DBMS_OUTPUT.PUT_LINE(v_nombre(indice));
        END IF;
    END LOOP;
  
    DBMS_OUTPUT.PUT_LINE(CHR(10));
    FOR indice IN v_nombre.FIRST..v_nombre.LAST LOOP
        IF v_nombre.EXISTS(indice) THEN
            UPDATE EMPLEADO
            SET SALARIO = 0
            , COMISION = 0
            WHERE NOMBRE = v_nombre(indice);
       
            UPDATE PLANTILLA
            SET SALARIO = 0
            WHERE NOMBRE = v_nombre(indice);
        
            IF SQL%NOTFOUND THEN
                DBMS_OUTPUT.PUT_LINE(CHR(10)||'No se encontraron empleados sanitarios con el nombre de '||v_nombre(indice));
            ELSE
                DBMS_OUTPUT.PUT_LINE(CHR(10)||'Se han actualizado '||SQL%ROWCOUNT||' empleados sanitarios con el nombre de '||v_nombre(indice));            
            END IF;
        END IF;
    END LOOP;
    ROLLBACK;
   END IF;
   CLOSE c_departamento;
END;
/